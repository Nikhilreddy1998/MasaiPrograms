import React, { useState } from "react";
import axios from "axios";

export default function Booking() {
  const [userId, setUserId] = useState("");
  const [parkingSpaceId, setSpace] = useState("");
  const [date, setDate] = useState("");

  const book = async () => {
    const res = await axios.post("http://localhost:5000/api/bookings/book", { userId, parkingSpaceId, date, status: "confirmed" });
    alert("Booking done");
  };

  return (
    <div>
      <h2>Book Parking</h2>
      <input placeholder="User ID" onChange={e => setUserId(e.target.value)} />
      <input placeholder="Parking Space ID" onChange={e => setSpace(e.target.value)} />
      <input type="date" onChange={e => setDate(e.target.value)} />
      <button onClick={book}>Book</button>
    </div>
  );
}