import React, { useEffect, useState } from "react";
import axios from "axios";

export default function App() {
  const [spaces, setSpaces] = useState([]);
  useEffect(() => {
    axios.get("http://localhost:5000/api/parking").then(res => setSpaces(res.data));
  }, []);

  return (
    <div>
      <h1>Available Parking Spaces</h1>
      <ul>
        {spaces.map(s => (
          <li key={s._id}>{s.location} - ₹{s.price}</li>
        ))}
      </ul>
    </div>
  );
}