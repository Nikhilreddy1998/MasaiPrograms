import mongoose from "mongoose";
const paymentSchema = new mongoose.Schema({
  userId: String,
  bookingId: String,
  amount: Number,
  status: String,
  date: { type: Date, default: Date.now }
});
export default mongoose.model("Payment", paymentSchema);