import mongoose from "mongoose";
const parkingSpaceSchema = new mongoose.Schema({
  location: String,
  capacity: Number,
  available: Boolean,
  price: Number
});
export default mongoose.model("ParkingSpace", parkingSpaceSchema);