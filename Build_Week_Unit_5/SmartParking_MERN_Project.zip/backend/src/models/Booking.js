import mongoose from "mongoose";
const bookingSchema = new mongoose.Schema({
  userId: String,
  parkingSpaceId: String,
  date: Date,
  status: String
});
export default mongoose.model("Booking", bookingSchema);