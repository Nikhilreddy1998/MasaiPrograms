import express from "express";
import Payment from "../models/Payment.js";
const router = express.Router();

router.post("/pay", async (req, res) => {
  const { userId, bookingId, amount } = req.body;
  const payment = await Payment.create({ userId, bookingId, amount, status: "success" });
  res.json(payment);
});

export default router;