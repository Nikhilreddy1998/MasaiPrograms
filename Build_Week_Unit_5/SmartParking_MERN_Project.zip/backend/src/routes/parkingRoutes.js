import express from "express";
import ParkingSpace from "../models/ParkingSpace.js";
const router = express.Router();

router.get("/", async (req, res) => {
  const spaces = await ParkingSpace.find();
  res.json(spaces);
});

router.post("/add", async (req, res) => {
  const data = await ParkingSpace.create(req.body);
  res.json(data);
});

export default router;