import express from "express";
import Booking from "../models/Booking.js";
const router = express.Router();

router.post("/book", async (req, res) => {
  const booking = await Booking.create(req.body);
  res.json(booking);
});

router.get("/:userId", async (req, res) => {
  const bookings = await Booking.find({ userId: req.params.userId });
  res.json(bookings);
});

export default router;